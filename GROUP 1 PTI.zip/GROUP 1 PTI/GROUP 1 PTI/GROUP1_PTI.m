%%
clc,clearvars,close all
%image importing
img1 = imread("leaf1.jpeg");
img2 = imread("leaf 3.jpg");
img3 = imread("leaf1.jpg");
img4 = imread("leaf2.jpeg");
img5 = imread("leaf2.jpg");
img6 = imread("leaf6.jpeg");
img7 = imread("leaf5.jpeg");
img8 = imread("leaf 4.jpg");
img9 = imread("leaf4.jpeg");
initialimages = {img1,img2,img3,img4,img5,img6,img7,img8};

%structuring
leaf(9) = struct('Name','','type','','shape','','margin','','venation','','image',[]);
leaf(1).Name="snippet";
leaf(1).type="compound";
leaf(1).shape="rounded";
leaf(1).margin="entire";
leaf(1).venation="pinnat ventation";
leaf(1).image = img1;

leaf(2).Name="sugarcane";
leaf(2).type="simple";
leaf(2).shape="oblongo";
leaf(2).margin="serrulate";
leaf(2).venation="parallel";
leaf(2).image = img2;



leaf(3).Name="coffee leave";
leaf(3).type="simple";
leaf(3).shape="elliptic";
leaf(3).margin="entire";
leaf(3).venation="pinnate";
leaf(3).image = img3;

leaf(4).Name="maize";
leaf(4).type="simple";
leaf(4).shape="long and flat";
leaf(4).margin="entire";
leaf(4).venation="parallel";
leaf(4).image = img4;

leaf(5).Name="bean";
leaf(5).type="simple";
leaf(5).shape="rounded";
leaf(5).margin="entire";
leaf(4).venation="pinnate";
leaf(5).image = img5;

leaf(6).Name="gauva";
leaf(6).type="simple";
leaf(6).shape="oblongo";
leaf(6).margin="entire";
leaf(6).venation="pinnate";
leaf(6).image = img6;

leaf(7).Name="sweet potato vain";
leaf(7).type="simple";
leaf(7).shape="smooth";
leaf(7).margin="entire";
leaf(7).venation="palmate";
leaf(7).image = img7;

leaf(8).Name="mango";
leaf(8).type="simple";
leaf(8).shape="rounded";
leaf(8).margin="entire";
leaf(8).venation="pinnate";
leaf(8).image = img8;

leaf(9).Name="citrus leaf";
leaf(9).type="simple";
leaf(9).shape="elliptic";
leaf(9).margin="entire";
leaf(8).venation="pinnate";
leaf(9).image = img9;
%graying
img1gray = im2gray(leaf(1).image);
img2gray = im2gray(leaf(2).image);
img3gray = im2gray(leaf(3).image);
img4gray = im2gray(leaf(4).image);
img5gray = im2gray(leaf(5).image);
img6gray = im2gray(leaf(6).image);
img7gray = im2gray(leaf(7).image);
img8gray = im2gray(leaf(8).image);
img9gray = im2gray(leaf(9).image);

%saving images
imwrite(img1gray,'img1gray.jpeg');
imwrite(img2gray,'img2gray.jpg');
imwrite(img3gray,'img3gray.jpg');
imwrite(img4gray,'img4gray.jpeg');
imwrite(img5gray,'img5gray.jpeg');
imwrite(img6gray,'img6gray.jpeg');
imwrite(img7gray,'img7gray.jpeg');
imwrite(img8gray,'img8gray.jpg');
imwrite(img9gray,'img9gray.jpeg');





%%
figure(1)
imshow(img1)
figure(2)
imshow(img2)
figure(3)
imshow(img3)
figure(4)
imshow(img4)
figure(5)
imshow(img5)
figure(6)
imshow(img6)
figure(7)
imshow(img7)
figure(8)
imshow(img8)
figure(9)
imshow(img9)







